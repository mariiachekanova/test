import { AdminTableSkeleton } from "@/components/skeletons"

export default function Loading() {
  return <AdminTableSkeleton />
}
