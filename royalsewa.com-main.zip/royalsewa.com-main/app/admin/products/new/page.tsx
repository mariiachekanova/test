"use client"

import AdminProductForm from "@/components/admin-product-form"

export default function NewProductPage() {
  return <AdminProductForm />
}
